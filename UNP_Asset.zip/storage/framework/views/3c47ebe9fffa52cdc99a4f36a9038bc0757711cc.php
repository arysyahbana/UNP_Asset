<div class="container-fluid warna_footer1 mt-3">
    <div class="container pt-5 pb-3">
        <div class="row justify-content-center">
            <div class="col col-4">
                <img src="<?php echo e(asset('dist_frontend/img/logo UNP Asset.svg')); ?>" alt="">
                <p class="fs-5 mt-3">Disini adalah solusi terbaik untuk kamu yang ingin mencari info seputar Asset
                    UNP
                </p>
            </div>
            <div class="col col-2"></div>
            <div class="col col-4">
                <p class="fw-bold fs-5">Contacts</p>
                <p>(02111) 512-5342</p>
                <p>Jl.Prof.Dr.Hamka,Air Tawar Bar,Kec.Padang Utara,Kota.Padang,Sumatera Barat 25172</p>
                <p>unpasset@gmail.com</p>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid bg-light text-center py-1">
    <p>Copyright &copy UNP Asset 2023 All rights reserved</p>
</div>
<?php /**PATH C:\Users\arysy\UNP_Asset\resources\views/frontend/partials/footer1.blade.php ENDPATH**/ ?>