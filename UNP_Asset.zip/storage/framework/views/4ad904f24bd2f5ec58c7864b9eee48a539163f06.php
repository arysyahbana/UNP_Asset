<?php $__env->startSection('title', 'UNP Asset | Upload'); ?>

<?php $__env->startSection('container'); ?>
    <div class="container mt-3">
        <div class="row">
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $path_photo = asset('storage/uploads/photo/' . $item->file);
                    $extphoto = pathinfo($path_photo, PATHINFO_EXTENSION);
                    
                    $path_video = asset('storage/uploads/video/' . $item->file);
                    $extvideo = pathinfo($path_video, PATHINFO_EXTENSION);
                    
                    $path_audio = asset('storage/uploads/audio/' . $item->file);
                    $extaudio = pathinfo($path_audio, PATHINFO_EXTENSION);
                    
                ?>
                <?php if($extphoto == 'jpg' || $extphoto == 'png' || $extphoto == 'jpeg'): ?>
                    <div class="col col-12 col-md-6 col-lg-3 my-2" data-aos="fade-up" data-aos-duration="1200">
                        <div class="card shadow">
                            <div class="card-header">
                                <p class="card-text text-center fs-5 fw-bold"><?php echo e($item->name); ?></p>
                            </div>
                            <img src="<?php echo e($path_photo); ?>" alt="" class="card-img-top img-fluid">
                            <div class="card-body">
                                <p class="text-success">Deskripsi :</p>
                                <p class="card-text"><?php echo e($item->body); ?></p>
                                <a href="<?php echo e(route('detail', [$item->id, $item->name])); ?>" class="btn btn-info">View</a>
                                <a href="<?php echo e(route('post_edit', $item->id)); ?>" class="btn btn-warning">Edit</a>
                                <a href="<?php echo e(route('post_delete', $item->id)); ?>"
                                    onclick="return confirm('data akan dihapus')" class="btn btn-danger">Delete</a>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                <?php if($extvideo == 'mp4' || $extvideo == 'mkv' || $extvideo == 'webm'): ?>
                    <div class="col col-12 col-md-6 col-lg-3 my-2" data-aos="fade-up" data-aos-duration="1200">
                        <div class="card shadow">
                            <div class="card-header">
                                <p class="card-text text-center fs-5 fw-bold"><?php echo e($item->name); ?></p>
                            </div>
                            <video controls>
                                <?php if($extvideo == 'mp4'): ?>
                                    <source src="<?php echo e($path_video); ?>" alt="" class="card-img-top img-fluid"
                                        type="video/mp4">
                                <?php endif; ?>
                                <?php if($extvideo == 'mkv'): ?>
                                    <source src="<?php echo e($path_video); ?>" alt="" class="card-img-top img-fluid"
                                        type="video/mkv">
                                <?php endif; ?>
                                <?php if($extvideo == 'webm'): ?>
                                    <source src="<?php echo e($path_video); ?>" alt="" class="card-img-top img-fluid"
                                        type="video/webm">
                                <?php endif; ?>
                            </video>
                            <div class="card-body">
                                <p class="text-success">Deskripsi :</p>
                                <p class="card-text"><?php echo e($item->body); ?></p>
                                <a href="<?php echo e(route('detail', [$item->id, $item->name])); ?>" class="btn btn-info">View</a>
                                <a href="<?php echo e(route('post_edit', $item->id)); ?>" class="btn btn-warning">Edit</a>
                                <a href="<?php echo e(route('post_delete', $item->id)); ?>"
                                    onclick="return confirm('data akan dihapus')" class="btn btn-danger">Delete</a>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                <?php if($extaudio == 'mp3' || $extaudio == 'm4a'): ?>
                    <div class="col col-12 col-md-6 col-lg-3 my-2" data-aos="fade-up" data-aos-duration="1200">
                        <div class="card shadow">
                            <div class="card-header">
                                <p class="card-text text-center fs-5 fw-bold"><?php echo e($item->name); ?></p>
                            </div>
                            <audio controls>
                                <?php if($extaudio == 'mp3'): ?>
                                    <source src="<?php echo e($path_audio); ?>" alt="" class="card-img-top img-fluid"
                                        type="audio/mp3">
                                <?php endif; ?>
                                <?php if($extaudio == 'm4a'): ?>
                                    <source src="<?php echo e($path_audio); ?>" alt="" class="card-img-top img-fluid"
                                        type="audio/m4a">
                                <?php endif; ?>
                            </audio>
                            <div class="card-body">
                                <p class="text-success">Deskripsi :</p>
                                <p class="card-text"><?php echo e($item->body); ?></p>
                                <a href="<?php echo e(route('detail', [$item->id, $item->name])); ?>" class="btn btn-info">View</a>
                                <a href="<?php echo e(route('post_edit', $item->id)); ?>" class="btn btn-warning">Edit</a>
                                <a href="<?php echo e(route('post_delete', $item->id)); ?>"
                                    onclick="return confirm('data akan dihapus')" class="btn btn-danger">Delete</a>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts2.main2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\arysy\UNP_Asset\resources\views/frontend/Post/front-post_show.blade.php ENDPATH**/ ?>