<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous">
</script>
<?php if($errors->any()): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <script>
            iziToast.error({
                title: '',
                position: 'topRight',
                message: '<?php echo e($error); ?>',
            });
        </script>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php endif; ?>
<?php if(session()->get('success')): ?>
    <script>
        iziToast.success({
            title: '',
            position: 'topRight',
            message: '<?php echo e(session()->get('success')); ?>',
        });
    </script>
<?php endif; ?>


<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>



<script>
    AOS.init();
</script>

<?php /**PATH C:\Users\arysy\UNP_Asset\resources\views/frontend/layouts/jsfrontfooter.blade.php ENDPATH**/ ?>