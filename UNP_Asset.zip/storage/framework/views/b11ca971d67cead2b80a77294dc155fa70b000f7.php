
<div class="container mt-5">
    <?php if(auth()->guard()->check()): ?>
        <?php if(Request::is('posts/create/*') || Request::is('posts/show/*')): ?>
            <ul class="nav nav-tabs">
                <li class="nav-item">
                    <a class="nav-link  mx-lg-4 <?php echo e(Request::is('posts/show/*') ? 'active text-danger' : 'text-dark'); ?>"
                        href="<?php echo e(route('post_show', [Auth::guard()->user()->id, Auth::guard()->user()->name])); ?>">My
                        Media</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-decoration-none mx-lg-4  <?php echo e(Request::is('posts/create/*') ? 'active text-danger' : 'text-dark'); ?>"
                        href="<?php echo e(route('post_create', [Auth::guard()->user()->id, Auth::guard()->user()->name])); ?>">Upload</a>
                </li>
            </ul>
        <?php endif; ?>
    <?php endif; ?>

</div>

<?php /**PATH C:\Users\arysy\UNP_Asset\resources\views/frontend/partials/navup.blade.php ENDPATH**/ ?>