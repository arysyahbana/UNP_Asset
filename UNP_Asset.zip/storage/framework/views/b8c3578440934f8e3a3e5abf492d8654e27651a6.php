<?php $__env->startSection('title', 'Show Category'); ?>

<?php $__env->startSection('main_content'); ?>
    <div class="container-fluid bg-light">

        <!-- DataTales Example -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Category</h6>
            </div>
            <div class="card-body">
                <div class="row justify-content-center">
                    <div class="col col-lg-8">
                        <div class="my-3">
                            <a href="<?php echo e(route('admin_category_create')); ?>" class="btn btn-primary"><i
                                    class="fas fa-plus fa-cog"></i> Add Category</a>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Category Name</th>
                                        <th>Show On Menu</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($category->name); ?></td>
                                            <td><?php echo e($category->show_on_menu); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('admin_category_edit', $category->id)); ?>"
                                                    class="btn btn-success"><i class="fa fa-edit"></i>
                                                    Edit</a>
                                                <a href="<?php echo e(route('admin_category_delete', $category->id)); ?>"
                                                    class="btn btn-danger" onclick="return confirm('are you sure?')"><i
                                                        class="fa fa-edit"></i>
                                                    Delete</a>

                                                
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\arysy\UNP_Asset\resources\views/admin/category/category_show.blade.php ENDPATH**/ ?>