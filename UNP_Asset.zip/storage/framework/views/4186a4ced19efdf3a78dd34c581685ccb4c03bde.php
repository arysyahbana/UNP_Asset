<?php $__env->startSection('title', 'Edit User'); ?>

<?php $__env->startSection('main_content'); ?>
    <div class="container-fluid">
        <div class="card">
            <form action="<?php echo e(route('admin_user_update', $edit->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="card-body">
                    <h5 class="card-title">Update User</h5>
                    <div class="mb-3">
                        <label class="form-label text-dark ">Name</label>
                        <input type="text" class="form-control" id="name" placeholder="Name"
                            value="<?php echo e($edit->name); ?>" name="name">
                    </div>
                    <div class="mb-3">
                        <label class="form-label text-dark ">Email</label>
                        <input type="email" class="form-control" id="email" placeholder="email"
                            value="<?php echo e($edit->email); ?>" name="email">
                    </div>
                    <div class="mb-3">
                        <label class="form-label text-dark ">New Password</label>
                        <input type="password" class="form-control" id="password" placeholder="Password" name="password">
                    </div>
                    <div class="mb-3">
                        <label class="form-label text-dark ">Retype Password</label>
                        <input type="password" class="form-control" id="password_confirmation" placeholder="Retype Password"
                            name="password_confirmation">
                    </div>
                    <div class="my-3">
                        <input type="submit" class="btn btn-primary" value="Update">
                    </div>
                </div>
            </form>
        </div>
    </div>
    <div class="" style="height: 35.5rem"></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\arysy\UNP_Asset\resources\views/admin/user/user_edit.blade.php ENDPATH**/ ?>