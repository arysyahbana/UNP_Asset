<?php $__env->startSection('title', 'UNP Asset | Detail'); ?>

<?php $__env->startSection('container'); ?>
    <div class="container mt-3">
        <div class="row justify-content-center">
            <?php
                $path_photo = asset('storage/uploads/photo/' . $post->file);
                $extphoto = pathinfo($path_photo, PATHINFO_EXTENSION);
                
                $path_video = asset('storage/uploads/video/' . $post->file);
                $extvideo = pathinfo($path_video, PATHINFO_EXTENSION);
                
                $path_audio = asset('storage/uploads/audio/' . $post->file);
                $extaudio = pathinfo($path_audio, PATHINFO_EXTENSION);
                
            ?>
            <div class="col col-6" data-aos="fade-up" data-aos-duration="1200">
                <?php if($extphoto == 'jpg' || $extphoto == 'png' || $extphoto == 'jpeg'): ?>
                    <div class="card">
                        <div class="car-body text-center">
                            <img src="<?php echo e(asset($path_photo)); ?>" class="img-fluid rounded-start" alt="..."
                                style="max-width: 30rem">
                        </div>
                    </div>
                <?php endif; ?>
                <?php if($extvideo == 'mp4' || $extvideo == 'mkv' || $extvideo == 'webm'): ?>
                    <div class="card">
                        <div class="card-body">
                            <video width="600" controls>
                                <?php if($extvideo == 'mp4'): ?>
                                    <source src="<?php echo e($path_video); ?>" alt="" type="video/mp4">
                                <?php endif; ?>
                                <?php if($extvideo == 'mkv'): ?>
                                    <source src="<?php echo e($path_video); ?>" alt="" type="video/mkv">
                                <?php endif; ?>
                                <?php if($extvideo == 'webm'): ?>
                                    <source src="<?php echo e($path_video); ?>" alt="" type="video/webm">
                                <?php endif; ?>
                            </video>
                        </div>
                    </div>
                <?php endif; ?>
                <?php if($extaudio == 'mp3' || $extaudio == 'm4a'): ?>
                    <div class="card">
                        <div class="card-body text-center">
                            <audio controls>
                                <?php if($extaudio == 'mp3'): ?>
                                    <source src="<?php echo e($path_audio); ?>" alt="" type="audio/mp3">
                                <?php endif; ?>
                                <?php if($extaudio == 'm4a'): ?>
                                    <source src="<?php echo e($path_audio); ?>" alt="" type="audio/m4a">
                                <?php endif; ?>
                            </audio>
                        </div>
                    </div>
                <?php endif; ?>
            </div>

            <div class="col col-4" data-aos="fade-down" data-aos-duration="1200">
                <div class="card">
                    <div class="card-body">
                        <h3><i class="bi bi-person-circle"></i> <?php echo e($post->rUser->name); ?></h3>
                        <h5>Kategori : <?php echo e($post->rCategory->name); ?></h5>
                        <h5><?php echo e($post->body); ?></h5>
                        <a href="<?php echo e(route('download', $post->file)); ?>" class="btn btn-success form-control" download>Free
                            Download</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts2.main2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\arysy\UNP_Asset\resources\views/frontend/detailhome.blade.php ENDPATH**/ ?>