<?php $__env->startSection('title', 'UNP Asset | Upload'); ?>

<?php $__env->startSection('container'); ?>
    <div class="container mt-3">
        <div class="row">
            <div class="col">
                <div class="card">
                    <div class="card-body">
                        
                        <form action="<?php echo e(route('post_store')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label for="exampleFormControlInput1" class="form-label">Title</label>
                                <input class="form-control form-control-md" type="text"
                                    aria-label=".form-control-lg example" name="title">
                            </div>

                            <div class="mb-3">
                                <label for="formFile" class="form-label">Input Your File</label>
                                <input class="form-control" type="file" name="file">
                            </div>

                            <div class="form-group mb-3">
                                <label>Category Menu?</label>
                                <select name="category_menu" class="form-control">
                                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>">
                                            <?php echo e($item->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label for="" class="form-label">Description</label>
                                <textarea class="form-control" id="" rows="3" name="body"></textarea>
                            </div>

                            <div class="text-end">
                                <input type="submit" class="btn btn-success px-4 py-2" value="Uploads">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts2.main2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\arysy\UNP_Asset\resources\views/frontend/Post/front_post_create.blade.php ENDPATH**/ ?>