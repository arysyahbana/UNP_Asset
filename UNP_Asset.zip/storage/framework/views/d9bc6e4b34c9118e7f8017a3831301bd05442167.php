 <!-- Bootstrap core JavaScript-->
 <script src="<?php echo e(asset('dist/vendor/jquery/jquery.min.js')); ?>"></script>
 <script src="<?php echo e(asset('dist/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

 <!-- Core plugin JavaScript-->
 <script src="<?php echo e(asset('dist/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>

 <!-- Custom scripts for all pages-->
 <script src="<?php echo e(asset('dist/js/sb-admin-2.min.js')); ?>"></script>

 <!-- Page level plugins -->
 <script src="<?php echo e(asset('dist/vendor/chart.js/Chart.min.js')); ?>"></script>

 <!-- Page level custom scripts -->
 <script src="<?php echo e(asset('dist/js/demo/chart-area-demo.js')); ?>"></script>
 <script src="<?php echo e(asset('dist/js/demo/chart-pie-demo.js')); ?>"></script>

 <!-- Page level plugins -->
 <script src="<?php echo e(asset('dist/vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
 <script src="<?php echo e(asset('dist/vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

 <!-- Page level custom scripts -->
 <script src="<?php echo e(asset('dist/js/demo/datatables-demo.js')); ?>"></script>
 <?php if($errors->any()): ?>
     <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <script>
             iziToast.error({
                 title: '',
                 position: 'topRight',
                 message: '<?php echo e($error); ?>',
             });
         </script>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <?php endif; ?>
 <?php if(session()->get('success')): ?>
     <script>
         iziToast.success({
             title: '',
             position: 'topRight',
             message: '<?php echo e(session()->get('success')); ?>',
         });
     </script>
 <?php endif; ?>
<?php /**PATH C:\Users\arysy\UNP_Asset\resources\views/admin/layouts/js_footer.blade.php ENDPATH**/ ?>