<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">


<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">


<link rel="stylesheet" href="<?php echo e(asset('dist_frontend/css/styles.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('dist_frontend/css/iziToast.min.css')); ?>">


<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

<?php /**PATH C:\Users\arysy\UNP_Asset\resources\views/frontend/layouts/cssfront.blade.php ENDPATH**/ ?>