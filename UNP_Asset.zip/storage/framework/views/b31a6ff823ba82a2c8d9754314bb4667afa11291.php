<div class="container-fluid bg-light text-center py-1">
    <p>Copyright &copy UNP Asset 2023 All rights reserved</p>
</div>
<?php /**PATH C:\Users\arysy\UNP_Asset\resources\views/frontend/partials/footer2.blade.php ENDPATH**/ ?>