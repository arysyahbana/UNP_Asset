<nav class="navbar navbar-expand-lg nav_color">
    <div class="container">
        <a class="navbar-brand" href="/"><img src="<?php echo e(asset('dist_frontend/img/logo UNP Asset.svg')); ?>"
                alt=""></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown"
            aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link active mx-4" aria-current="page" href="/">Home</a>
                </li>
                
                <?php if(auth()->guard()->check()): ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                            aria-expanded="false">
                            <i class="bi bi-person-circle"></i>

                            <?php echo e(Auth::guard()->user()->name); ?>

                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="<?php echo e(route('profile_edit', Auth::guard()->user()->id)); ?>"><i
                                        class="bi bi-file-text"></i>
                                    My Profile</a></li>
                            

                            <li><a class="dropdown-item" href="<?php echo e(route('user_logout')); ?>"><i
                                        class="bi bi-box-arrow-left"></i> Logout</a></li>
                        <?php endif; ?>

                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH C:\Users\arysy\UNP_Asset\resources\views/frontend/partials/nav.blade.php ENDPATH**/ ?>