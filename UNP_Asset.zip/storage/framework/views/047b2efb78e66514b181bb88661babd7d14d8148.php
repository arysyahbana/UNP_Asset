<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Reset</title>
    <?php echo $__env->make('admin.layouts.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <div class="container">
        <?php if(session()->get('berhasil')): ?>
            <div class="alert alert-success"><?php echo e(session()->get('berhasil')); ?></div>
        <?php elseif(session()->get('error')): ?>
            <div class="alert alert-danger"><?php echo e(session()->get('error')); ?></div>
        <?php endif; ?>
        <div class="row justify-content-center mt-5">
            <div class="col col-6 pt-5">
                <form action="<?php echo e(route('user_reset_submit')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="token" value="<?php echo e($token); ?>">
                    <input type="hidden" name="email" value="<?php echo e($email); ?>">
                    <div class="text-center my-3">
                        <img src="<?php echo e(asset('dist_frontend/img/logo UNP Asset.svg')); ?>" alt="" class="img-fluid">
                    </div>

                    <div class="card pb-5 shadow">
                        <div class="card-body">
                            <h2 class="fw-bold text-dark">Reset Password</h2>
                            <div class="py-3">
                                <label class="form-label">Password</label>
                                <input type="password" class="form-control" name='password' id="password">
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="py-3">
                                <label class="form-label">Retype Password</label>
                                <input type="password" class="form-control" name='new_password' id="new_password">
                                <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="d-flex justify-content-center mb-3">
                                <button type="submit" class="btn btn-success px-auto">Change Password</button>
                            </div>
                        </div>
                </form>
            </div>
        </div>
    </div>
    <?php echo $__env->make('admin.layouts.js_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH C:\Users\arysy\UNP_Asset\resources\views/frontend/login/front_reset.blade.php ENDPATH**/ ?>