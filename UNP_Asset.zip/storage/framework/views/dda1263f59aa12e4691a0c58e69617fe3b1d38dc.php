<script src="<?php echo e(asset('dist/js/iziToast.min.js')); ?>"></script>
<?php /**PATH C:\Users\arysy\UNP_Asset\resources\views/admin/layouts/js_header.blade.php ENDPATH**/ ?>