<!-- Awal Banner -->
<div class="container-fluid banner">
    <div class="row pt-3">
        <div class="col col-12 col-md-6 col-lg-6">
            <img src="<?php echo e(asset('dist_frontend/img/logo UNP Asset.svg')); ?>" alt="">
        </div>
        <div class="col col-12 col-md-6 col-lg-6 d-flex justify-content-end">
            <?php if(auth()->guard()->check()): ?>
                <span class="btn btn-outline-success rounded-pill"><i class="bi bi-person-circle"></i>
                    <?php echo e(Auth::guard()->user()->name); ?></span>
                <a href="<?php echo e(route('post_create', [Auth::guard()->user()->id, Auth::guard()->user()->name])); ?>"
                    class="btn btn-danger rounded-pill px-4 mx-4"><i class="bi bi-upload"></i> Unggah</a>
            <?php else: ?>
                <a href="#" class="btn btn-outline-success rounded-pill px-lg-4" data-bs-toggle="modal"
                    data-bs-target="#order"><i class="bi bi-box-arrow-in-right"></i> Log in</a>
                <a href="<?php echo e(route('user_signup')); ?>" class="btn btn-outline-danger rounded-pill px-lg-4 ms-4"><i
                        class="bi bi-plus-square"></i> Sign up</a>
                <a href="<?php echo e(route('post_create', ['ads', 'asd'])); ?>" class="btn btn-danger rounded-pill px-lg-4 mx-4"><i
                        class="bi bi-upload"></i> Unggah</a>
            <?php endif; ?>
        </div>
    </div>
    <div class="row justify-content-center pt-lg-5">
        <?php if(Request::path() == 'photo'): ?>
            <div class="col col-12 col-lg-8 d-flex justify-content-center mt-5" data-aos="zoom-in-down"
                data-aos-duration="1200">
                <p class="display-5 fw-bold mt-5 text-center">Stock Photo Gratis dari Orang Berbakat Universitas Negeri
                    Padang </p>
            </div>
            <div class="col col-12 col-lg-6 text-center mt-3">
                <form action="<?php echo e(route('photo')); ?>" method="GET">
                    <div class="input-group mb-3">
                        <input type="text" class="form-control py-3 rounded-start-pill" placeholder="Search.."
                            name="search_photo" value="<?php echo e(request('search')); ?>">
                        <button class="btn warna_search rounded-end-pill" type="submit"><i
                                class="bi bi-search"></i></button>
                    </div>
                </form>
            </div>
        <?php elseif(Request::path() == 'video'): ?>
            <div class="col col-12 col-lg-8 d-flex justify-content-center mt-5" data-aos="zoom-in-down"
                data-aos-duration="1200">
                <p class="display-5 fw-bold mt-5 text-center">Rekaman & Stok Video Gratis dari Orang Berbakat </p>
            </div>
            <div class="col col-12 col-lg-6 text-center mt-3">
                <form action="<?php echo e(route('video')); ?>" method="GET">
                    <div class="input-group mb-3">
                        <input type="text" class="form-control py-3 rounded-start-pill" placeholder="Search.."
                            name="search_video" value="<?php echo e(request('search')); ?>">
                        <button class="btn warna_search rounded-end-pill" type="submit"><i
                                class="bi bi-search"></i></button>
                    </div>
                </form>
            </div>
        <?php elseif(Request::path() == 'audio'): ?>
            <div class="col col-12 col-lg-8 d-flex justify-content-center mt-5" data-aos="zoom-in-down"
                data-aos-duration="1200">
                <p class="display-5 fw-bold mt-5 text-center">Rekomendasi Musik Gratis dari Orang Berbakat </p>
            </div>
            <div class="col col-12 col-lg-6 text-center mt-3">
                <form action="<?php echo e(route('audio')); ?>" method="GET">
                    <div class="input-group mb-3">
                        <input type="text" class="form-control py-3 rounded-start-pill" placeholder="Search.."
                            name="search_audio" value="<?php echo e(request('search')); ?>">
                        <button class="btn warna_search rounded-end-pill" type="submit"><i
                                class="bi bi-search"></i></button>
                    </div>
                </form>
            </div>
        <?php else: ?>
            <div class="col col-12 col-lg-8 d-flex justify-content-center mt-5" data-aos="zoom-in-down"
                data-aos-duration="1200">
                <p class="display-5 fw-bold mt-5 text-center">Temukan Hal Yang Menakjubkan di Sekitar Universitas Negeri
                    Padang</p>
            </div>
            <div class="col col-12 col-lg-6 text-center mt-3">
                <form action="<?php echo e(route('home')); ?>" method="GET">
                    <div class="input-group mb-3">
                        <input type="text" class="form-control py-3 rounded-start-pill" placeholder="Search.."
                            name="search" value="<?php echo e(request('search')); ?>">
                        <button class="btn warna_search rounded-end-pill" type="submit"><i
                                class="bi bi-search"></i></button>
                    </div>
                </form>
            </div>
        <?php endif; ?>
        

    </div>
</div>
<!-- Akhir Banner -->

<!-- Awal modal -->
<div class="modal fade" id="order" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <!-- <h1 class="modal-title fs-5" id="exampleModalLabel">Modal title</h1> -->
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="container">
                    <div class="row">
                        <div class="col text-center">
                            <img src="<?php echo e(asset('dist_frontend/img/logo UNP Asset.svg')); ?>" alt="">
                            <h2 class="fw-bold">Login</h2>
                        </div>
                    </div>
                    <form action="<?php echo e(route('user_login_submit')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="py-3">
                            <label class="form-label">Email address</label>
                            <input type="email" class="form-control" name='email' id="email"
                                aria-describedby="emailHelp">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Password</label>
                            <input type="password" class="form-control" name='password' id="password">
                        </div>
                        <div class="mb-3">
                            <a href="<?php echo e(route('user_forget')); ?>" class="text-decoration-none">Forget password?</a>
                        </div>
                        <div class="modal-footer">
                            <input type="submit" class="btn btn-success form-control" value="Login">
                            <!-- <button type="button" class="btn btn-primary">Save changes</button> -->
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>
<!-- Akhir modal -->
<?php /**PATH C:\Users\arysy\UNP_Asset\resources\views/frontend/partials/banner.blade.php ENDPATH**/ ?>