<?php $__env->startSection('title', 'UNP Asset | Edit'); ?>

<?php $__env->startSection('container'); ?>
    <div class="container mt-3">
        <div class="row">
            <div class="col">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Update your post</h5>
                        <form action="<?php echo e(route('post_update', $edit->id)); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label for="exampleFormControlInput1" class="form-label">Title</label>
                                <input class="form-control form-control-md" type="text"
                                    aria-label=".form-control-lg example" name="title">
                            </div>

                            <div class="mb-3">
                                <label for="" class="form-label">Description</label>
                                <textarea class="form-control" id="" rows="3" name="body"></textarea>
                            </div>

                            <div class="text-end">
                                <input type="submit" class="btn btn-success px-4 py-2" value="Update">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts2.main2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\arysy\UNP_Asset\resources\views/frontend/Post/front_post_edit.blade.php ENDPATH**/ ?>