<script src="{{ asset('dist/js/iziToast.min.js') }}"></script>
