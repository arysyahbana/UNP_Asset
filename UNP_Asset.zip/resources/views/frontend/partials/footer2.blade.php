<div class="container-fluid bg-light text-center py-1">
    <p>Copyright &copy UNP Asset 2023 All rights reserved</p>
</div>
