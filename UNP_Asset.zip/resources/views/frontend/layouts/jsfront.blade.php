<script src="{{ asset('dist_frontend/js/iziToast.min.js') }}"></script>
